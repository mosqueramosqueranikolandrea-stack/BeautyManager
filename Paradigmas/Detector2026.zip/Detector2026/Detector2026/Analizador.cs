﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Detector2026
{
    internal class Analizador
    {
        private Virus[] listaVirus = new Virus[5];
        private byte[] contenidoArchivo;
        private int contadorUsama = 0;
        private int contadorAntrax = 0;
        private int contadorEBola = 0;
        private int contadorAh1n1 = 0;
        private int contadorCovid = 0;

        public Analizador(byte[] contenidoBytes) {

            contenidoArchivo = contenidoBytes;
            crearListaVirus();
        }
        private void crearListaVirus()
        {
            Virus usama = new Virus("USAMA", new byte[] { 10, 101, 110, 100 });
            Virus antrax = new Virus("AMTRAX", new byte[] { 15, 30, 15, 49 });
            Virus eBola = new Virus("eBOLA", new byte[] { 15, 30, 15, 49 });
            Virus ah1n1 = new Virus("AH1N1", new byte[] { 15, 30, 15, 49 });
            Virus covid = new Virus("Covid 19", new byte[] { 15, 30, 15, 49 });

            listaVirus[0] = usama;
            listaVirus[1] = antrax;
            listaVirus[2] = eBola;
            listaVirus[3] = ah1n1;
            listaVirus[4] = covid;
        }

        public string analizar(){

            string estado = "q0";
            for (int i = 0; i < contenidoArchivo.Length; i++){
                if (contenidoArchivo[i] == listaVirus[0].getSecuenciaVirus()[0]) {
                    //q1
                    estado = "q1";
                    if (contenidoArchivo[i + 1] == listaVirus[0].getSecuenciaVirus()[1]) {
                        //q2
                        estado = "q2";
                        if (contenidoArchivo[i + 2] == listaVirus[0].getSecuenciaVirus()[2]) {
                            //q3
                            estado = "q3";
                            if (contenidoArchivo[i + 3] == listaVirus[0].getSecuenciaVirus()[3]){
                                
                                Console.WriteLine("USAMA encontrado");
                                contadorUsama++;
                                estado = "q4";

                            }
                    }
                }
                }
                if (contenidoArchivo[i] == listaVirus[1].getSecuenciaVirus()[0])
                {
                    //q1
                    estado = "q1";
                    if (contenidoArchivo[i + 1] == listaVirus[1].getSecuenciaVirus()[1])
                    {
                        //q2
                        estado = "q2";
                        if (contenidoArchivo[i + 2] == listaVirus[1].getSecuenciaVirus()[2])
                        {
                            //q3
                            estado = "q3";
                            if (contenidoArchivo[i + 3] == listaVirus[1].getSecuenciaVirus()[3])
                            {

                                Console.WriteLine("ANTRAX encontrado");
                                contadorAntrax++;
                                estado = "q4";

                            }
                        }
                    }
                }
            }
            return estado;
        }

        public int getContadorUsama() {
            return contadorUsama;
        }
         public int getContadorAntrax()
        {
            return contadorAntrax;
        }
         public int getContadorEBola()
        {
            return contadorEBola;
        }
         public int getContadorAh1n1()
        {
            return contadorAh1n1;
        }
         public int getContadorCovid()
        {
            return contadorCovid;
         }
    }
}
