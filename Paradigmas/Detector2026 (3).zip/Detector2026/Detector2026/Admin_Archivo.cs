﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Detector2026
{
    internal class Admin_Archivo
    {
        public Admin_Archivo(){

        }
       public byte[] leerBytes(string ruta){

            byte[] bytes = File.ReadAllBytes(ruta);

            return bytes;
        }
    }
}
