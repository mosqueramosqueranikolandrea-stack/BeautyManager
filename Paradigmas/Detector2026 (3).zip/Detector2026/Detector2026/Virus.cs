﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Detector2026
{
    internal class Virus
    {

        private string nombreVirus;
        private byte[] secuenciaVirus;

        public Virus(string nombre, byte[] secuencia)
        {
            nombreVirus = nombre;
            secuenciaVirus = secuencia;
        }
        public byte[] getSecuenciaVirus(){
            return secuenciaVirus;
        }
    }
}
